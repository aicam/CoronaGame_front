export class Urls {
  static P_URL = 'http://192.168.43.242:4500/';
  static G_URL = 'https://beacongameserver.ir/rl/';
  static H_URL = 'http://192.168.43.78:4200/';
}
