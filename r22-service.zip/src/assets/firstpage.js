function openForm() {
  var popup = document.getElementById("myForm");
  popup.style.display = "block";
  popup.classList.toggle("show");
}
function openForm_v() {
  var popup_v = document.getElementById("myForm-v");
  popup_v.style.display = "block";
  popup_v.classList.toggle("show");
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}

function closeForm_v() {
  document.getElementById("myForm").style.display = "none";
}
