export class Urls {
  static P_URL = 'http://192.168.1.13:4500/';
  static G_URL = 'http://192.168.1.10/';
  static H_URL = 'http://192.168.1.10:4200/';
}
